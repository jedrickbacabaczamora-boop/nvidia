<html class=" js no-touch">
 <head> 
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8"> 
  <title>Cashkumar - Deposit</title> 
  <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
  <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0"> 
  <meta name="apple-mobile-web-app-capable" content="yes"> 
  <meta name="apple-mobile-web-app-status-bar-style" content="black"> 
  <meta name="format-detection" content="telephone=no"> 
  <meta name="wap-font-scale" content="no">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/layui/2.5.7/css/layui.min.css">
  <link rel="stylesheet" href="/static/home/css/reset.css"> 
  <link rel="stylesheet" href="/static/home/css/style.css"> 
  <link rel="stylesheet" href="/static/home/layui/css/layui.css"> 
  <link id="layuicss-layer" rel="stylesheet" href="https://www.cashkumarinvest.com/static/home/layui/css/modules/layer/default/layer.css?v=3.1.1" media="all">
 </head> 
 <body class="bgColor"> 
  <div class="headTop"> 
   <a href="https://www.cashkumarinvest.com"> <i class="layui-icon layui-icon-left" style="font-size: 22px; color: #000;"></i> </a> Deposit 
  </div> 
  <div class="news-change"> 
   <a class="cur" href="https://www.cashkumarinvest.com/recharge/cash"><img src="/static/home/images/u_1.png" alt=""> CASH ACCOUNT</a> 
   <a href="https://www.cashkumarinvest.com/recharge/usdt"><img src="/static/home/images/u_4.png" alt="">USDT ACCOUNT</a> 
  </div> 
  <div class="rechargeWallet"> 
   <p> Account balance</p> 
   <h3>₹ <span>101</span></h3> 
   <small>≈ ₮1.1348</small> 
  </div> 
  <div class="recharge"> 
   <div class="recharge-all"> 
    <div class="recharge-amounts"> 
     <div class="recharge-tit">
      Quick amount
     </div> 
     <div class="recharge-input-new"> 
      <p>Amount</p> 
      <i>₹</i> 
      <input type="number" name="amount" placeholder="please enter deposit amount..."> 
     </div> 
     <div class="recharge-click"> 
      <ul> 
       <li data-amount="1000">₹<span>1,000</span></li> 
       <li data-amount="3000">₹<span>3,000</span></li> 
       <li data-amount="5000">₹<span>5,000</span></li> 
       <li data-amount="10000">₹<span>10,000</span></li> 
       <li data-amount="30000">₹<span>30,000</span></li> 
       <li data-amount="50000">₹<span>50,000</span></li> 
      </ul> 
     </div> 
    </div> 
    <div class="recharge-change"> 
     <div class="recharge-tit">
      Deposit Channel
     </div> 
     <div class="recharge-list"> 
     @foreach(\App\Models\PaymentMethod::get() as $el)
  <div class="recharge-li" data-method="{{ $el->id }}">
    <div> 
      <h3>{{ $el->name }}</h3> 
      <p>₹200 ~ ₹100,000</p> 
    </div> 
    <i></i> 
  </div> 
@endforeach

    </div>
    </div> 
    <div class="recharge-change"> 
     <button type="button" class="recharge-btn">To Deposit</button> 
    </div> 
    <div class="recharge-rultit">
     <i></i>Explain
    </div> 
    <div class="recharge-rul"> 
     <p><span style="text-wrap: nowrap;"></span></p>
     <p><span style="text-wrap: nowrap; font-size: 14px; font-family: ">1. The minimum recharge amount is ₹200, and the minimum recharge amount for TRC-20 cryptocurrency is ₮10 USDT.</span></p>
     <p><span style="text-wrap: nowrap; font-size: 14px; font-family: "><br></span></p>
     <p><span style="text-wrap: nowrap; font-size: 14px; font-family: ">2. Please ensure that the payment amount matches the amount you entered. To ensure a smooth recharge, you must fill out and submit the recharge order according to the process each time. Do not make a direct payment to the receiving account without submitting an order.</span></p>
     <p><span style="text-wrap: nowrap; font-size: 14px; font-family: "><br></span></p>
     <p><span style="text-wrap: nowrap; font-size: 14px; font-family: "></span>3. If the funds have not arrived within 5 minutes after payment, please contact the platform customer service for assistance.<span style="text-wrap: nowrap;"></span><br></p>
     <p></p>
     <p></p>
     <p></p>
     <p></p>
     <p></p>
     <p></p>
     <p></p>
     <p></p>
     <p></p>
     <p></p>
     <p></p>
     <p></p>
     <p></p>
     <p></p>
     <p></p>
     <p></p>
     <p></p>
     <p></p> 
    </div> 
   </div> 
  </div> 
  
<script src="/static/home/layui/layui.js"></script>
<script>
  // Highlight and fill selected amount
  document.querySelectorAll('.recharge-click li').forEach(el => {
    el.addEventListener('click', function () {
      document.querySelectorAll('.recharge-click li').forEach(li => li.classList.remove('cur'));
      this.classList.add('cur');
      const amount = this.getAttribute('data-amount');
      document.querySelector('input[name="amount"]').value = amount;
    });
  });

  // Highlight selected payment channel
  document.querySelectorAll('.recharge-li').forEach(el => {
    el.addEventListener('click', function () {
      document.querySelectorAll('.recharge-li').forEach(li => li.classList.remove('cur'));
      this.classList.add('cur');
    });
  });

  // Handle To Deposit button click
  document.querySelector('.recharge-btn').addEventListener('click', function () {
    const amount = document.querySelector('input[name="amount"]').value;
    const selectedChannel = document.querySelector('.recharge-li.cur');

    if (!selectedChannel) {
      layer.msg("Please select a payment channel", { icon: 5 });
      return;
    }

    if (!amount || parseFloat(amount) < 200) {
      layer.msg("Minimum deposit amount is ₹200", { icon: 5 });
      return;
    }

    const methodId = selectedChannel.getAttribute('data-method');
    const redirectUrl = `/user/payment/${amount}/${methodId}`;
    
    window.location.href = redirectUrl;
  });
</script>
